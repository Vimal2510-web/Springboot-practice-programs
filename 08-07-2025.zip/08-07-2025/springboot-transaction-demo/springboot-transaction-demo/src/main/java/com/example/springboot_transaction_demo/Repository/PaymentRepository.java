package com.example.springboot_transaction_demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springboot_transaction_demo.Entity.Payment;

public interface PaymentRepository extends JpaRepository <Payment, Long>{

}
