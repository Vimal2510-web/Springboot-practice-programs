package com.example.springboot_transaction_demo.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderResponse {
	
	private String orderTrackingNumber;
	private String status;
	private String message;
	public String getOrderTrackingNumber() {
		return orderTrackingNumber;
	}
	public void setOrderTrackingNumber(String orderTrackingNumber) {
		this.orderTrackingNumber = orderTrackingNumber;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	

}
