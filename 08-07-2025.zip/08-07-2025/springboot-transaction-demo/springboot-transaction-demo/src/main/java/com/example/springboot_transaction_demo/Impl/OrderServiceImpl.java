package com.example.springboot_transaction_demo.Impl;

import java.util.UUID;

import org.springframework.stereotype.Service;

import com.example.springboot_transaction_demo.DTO.OrderRequest;
import com.example.springboot_transaction_demo.DTO.OrderResponse;
import com.example.springboot_transaction_demo.Entity.Order;
import com.example.springboot_transaction_demo.Entity.Payment;
import com.example.springboot_transaction_demo.Exception.PaymentException;
import com.example.springboot_transaction_demo.Repository.OrderRepository;
import com.example.springboot_transaction_demo.Repository.PaymentRepository;
import com.example.springboot_transaction_demo.Service.OrderService;

import jakarta.transaction.Transactional;

@Service
public class OrderServiceImpl implements OrderService {

	private OrderRepository orderRepository;
	private PaymentRepository paymentRepository;
	
	public OrderServiceImpl(OrderRepository orderRepository, PaymentRepository paymentRepository) {
		super();
		this.orderRepository = orderRepository;
		this.paymentRepository = paymentRepository;
	}
	
	@Override
	@Transactional
	public OrderResponse placeOrder(OrderRequest orderRequest) {
		
		Order order = orderRequest.getOrder();
		order.setStatus("IN PROGRESS");
		order.setOrderTrackingNumber(UUID.randomUUID().toString());
		orderRepository.save(order);
		
		Payment payment = orderRequest.getPayment();
		
		if(!payment.getType().equals("DEBIT")) {
			throw new PaymentException("Payment card type do not support");
		}
		
		payment.setOrderId(order.getId());
		paymentRepository.save(payment);
		
		OrderResponse orderResponse = new OrderResponse();
		
		orderResponse.setOrderTrackingNumber(order.getOrderTrackingNumber());
		orderResponse.setStatus(order.getStatus());
		orderResponse.setMessage("SUCCESS");
		
		
		return orderResponse;
	}

}
