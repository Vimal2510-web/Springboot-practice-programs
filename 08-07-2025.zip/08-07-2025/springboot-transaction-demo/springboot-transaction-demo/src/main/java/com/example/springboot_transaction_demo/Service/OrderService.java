package com.example.springboot_transaction_demo.Service;

import com.example.springboot_transaction_demo.DTO.OrderRequest;
import com.example.springboot_transaction_demo.DTO.OrderResponse;

public interface OrderService {
	
	OrderResponse placeOrder(OrderRequest orderRequest);

}
