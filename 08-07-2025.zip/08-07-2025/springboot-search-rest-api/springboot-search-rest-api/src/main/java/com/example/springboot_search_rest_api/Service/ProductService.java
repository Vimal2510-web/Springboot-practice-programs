package com.example.springboot_search_rest_api.Service;

import java.util.List;

import com.example.springboot_search_rest_api.Entity.Product;

public interface ProductService {
	
	List<Product> searchProducts(String query);
	
	Product createProduct (Product product);

}
