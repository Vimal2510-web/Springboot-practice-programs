package com.example.springboot_search_rest_api.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.springboot_search_rest_api.Entity.Product;
import com.example.springboot_search_rest_api.Repository.ProductRepository;
import com.example.springboot_search_rest_api.Service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	
	private ProductRepository productRepository;

	public ProductServiceImpl(ProductRepository productRepository) {
		super();
		this.productRepository = productRepository;
	}

	@Override
	public List<Product> searchProducts(String query) {
		
		List<Product> products = productRepository.searchProduct(query);
		return products;
	}

	@Override
	public Product createProduct(Product product) {
		
		return productRepository.save(product);
		
	}

}
