package com.example.spring_boot_data_jpa.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.spring_boot_data_jpa.Entity.Product;

public interface ProductRepository extends JpaRepository<Product,Long> {

}
