package com.example.spring_boot_data_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
