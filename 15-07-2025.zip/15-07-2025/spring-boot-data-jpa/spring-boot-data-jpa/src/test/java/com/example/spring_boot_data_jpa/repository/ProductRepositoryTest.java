package com.example.spring_boot_data_jpa.repository;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.spring_boot_data_jpa.Entity.Product;
import com.example.spring_boot_data_jpa.Repository.ProductRepository;

@SpringBootTest
class ProductRepositoryTest {
	
	@Autowired
	private ProductRepository productRepository;
	
	@Test
	void saveMethod() {
		
		// create product
		
		Product product = new Product();
		
		product.setName("product 1");
		product.setPrice(new BigDecimal (1000));
		product.setActive(true);
		product.setSku("101ABC");
		product.setDescription("product 1 description");
		product.setImageUrl("product1.png");
		
		// save product
		
		Product savedObject = productRepository.save(product);
		
		// display product info
		
		System.out.println(savedObject.getId());
		System.out.println(savedObject.toString());
	}
	
	@Test
	void updateUsingsaveMethod() {
		
		// finding entity by id
		
		Long id = 1L;
		Product product = productRepository.findById(id).get();
		
		// update an entity info
		
		product.setName("updated product 1");
		product.setDescription("updated product 1 description");
		
		// save entity
		
		productRepository.save(product);
	}
	
	 @Test
	 void saveAllMethod() {
		 
		 // create products
		 
		 Product product2 = new Product();
			
			product2.setName("product 2");
			product2.setPrice(new BigDecimal (1234));
			product2.setActive(false);
			product2.setSku("102ABC");
			product2.setDescription("product 2 description");
			product2.setImageUrl("product2.png");
			
			
			Product product3 = new Product();
			
			product3.setName("product 3");
			product3.setPrice(new BigDecimal (100));
			product3.setActive(true);
			product3.setSku("103ABC");
			product3.setDescription("product 3 description");
			product3.setImageUrl("product3.png");
			
			// save entity 
			
			productRepository.saveAll(List.of(product2,product3));
	 }
	 
	 @Test
	 void findAllMethod() {
		 
		List <Product> product = productRepository.findAll();
		
		product.forEach((p) -> {
			System.out.println(p.getName());
		});
	 }
	 
	 @Test
	 void deleteByIdMethod() {
		 
		 Long id = 2L;
		 productRepository.deleteById(id);
	 }
	 
	 @Test
	 void deleteMethod() {
		 
		 // find entity by Id
		 
		 Long id = 1L;
		 Product product = productRepository.findById(id).get();
		 
		 // delete entity
		 
		 productRepository.delete(product);
	 }
	 
	 @Test
	 void deleteAllMethod() {
		 
		 // delete all entities of table
		 // productRepository.deleteAll();;
		 
		 // to delete particular entity of table
		 
		 Product product1 = productRepository.findById(5L).get();
		 Product product2 = productRepository.findById(6L).get();
		 
		 productRepository.deleteAll(List.of(product1,product2));
	 }
	 
	 @Test
	 void countMethod() {
		 
		 long count = productRepository.count();
		 System.out.println(count);
	 }
	 
	 @Test
	 void existsByIdMethod() {
		 
		 Long id = 1L;
		 boolean result = productRepository.existsById(id);
		 
		 System.out.println(result);
	 }

}
